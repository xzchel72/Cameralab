// Переключение темы и лёгкая анимация звёзд на canvas.
(() => {
  const root = document.documentElement;
  const toggle = document.getElementById("themeToggle");
  const savedTheme = localStorage.getItem("cameraLabTheme");
  if (savedTheme === "dark") root.dataset.theme = "dark";
  updateToggle();

  toggle.addEventListener("click", () => {
    const dark = root.dataset.theme !== "dark";
    if (dark) root.dataset.theme = "dark";
    else delete root.dataset.theme;
    localStorage.setItem("cameraLabTheme", dark ? "dark" : "light");
    updateToggle();
  });

  function updateToggle() {
    const dark = root.dataset.theme === "dark";
    toggle.innerHTML = dark ? "☀ <span>Тема</span>" : "☾ <span>Тема</span>";
    toggle.setAttribute("aria-label", dark ? "Включить светлую тему" : "Включить тёмную тему");
  }

  const canvas = document.getElementById("stars");
  const ctx = canvas.getContext("2d");
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  let width = 0, height = 0, stars = [];
  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = window.innerWidth; height = window.innerHeight;
    canvas.width = width * dpr; canvas.height = height * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    stars = Array.from({length: Math.min(100, Math.floor(width * height / 11000))}, () => ({
      x: Math.random() * width, y: Math.random() * height,
      r: Math.random() * 1.25 + .25, a: Math.random() * .5 + .15,
      speed: (Math.random() * .22 + .04) * (Math.random() < .5 ? -1 : 1)
    }));
    draw(true);
  }
  function draw(staticOnly = false) {
    ctx.clearRect(0, 0, width, height);
    const dark = root.dataset.theme === "dark";
    for (const s of stars) {
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      ctx.fillStyle = dark ? `rgba(190,185,255,${s.a})` : `rgba(103,89,232,${s.a * .55})`;
      ctx.fill();
      if (!staticOnly && !reduceMotion) {
        s.y += s.speed;
        if (s.y < -2) s.y = height + 2;
        if (s.y > height + 2) s.y = -2;
      }
    }
    if (!staticOnly && !reduceMotion) requestAnimationFrame(() => draw());
  }
  window.addEventListener("resize", resize);
  resize();
  // Перерисовать звёзды при смене темы.
  toggle.addEventListener("click", () => draw(true));
})();
